package com.example.lab8

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Spinner

class MainActivity : AppCompatActivity() {
    private lateinit var answer : Spinner
    private lateinit var checkButton : Button
    private var mydataClass = DataClass()
    private var selectedAnswer = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        answer =findViewById(R.id.answer)
        checkButton = findViewById(R.id.checkAnswer)

        checkButton.setOnClickListener {
            selectedAnswer= answer.selectedItemPosition
            mydataClass.correctAns(selectedAnswer)
            Log.i("answer take",mydataClass.answers)
            Log.i("check answer",mydataClass.checks)

            val intent = Intent(this,DisplayAnswer::class.java )
            intent.putExtra("answers",mydataClass.answers)
            intent.putExtra("checks",mydataClass.checks)
            startActivity(intent)
        }
    }


}