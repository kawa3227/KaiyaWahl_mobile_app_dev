package com.example.lab8

data class DataClass(var answers: String="", var checks: String="") {
    fun correctAns(position: Int){
        setAnswer(position)
        checkAns(position)
    }
    private fun setAnswer(position: Int){
        when(position){
            0 -> answers="11"
            1 -> answers="13"
            2 -> answers="15"
        }
    }
    private fun checkAns(position: Int){
        when (position){
            0 -> checks="https://www.calculator.net/"
            1 -> checks="https://www.youtube.com/watch?v=SC4xMk98Pdc"
            2 -> checks="https://www.calculator.net/"
        }
    }
}