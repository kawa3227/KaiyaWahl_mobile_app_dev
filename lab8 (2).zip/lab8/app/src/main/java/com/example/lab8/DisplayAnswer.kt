package com.example.lab8

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lab8.databinding.ActivityDisplayAnswerBinding

class DisplayAnswer : AppCompatActivity() {

   // private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityDisplayAnswerBinding
    private lateinit var ans : TextView

    private var answs : String? = null
    private var chcks : String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDisplayAnswerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        ans=findViewById(R.id.answ)

        answs= intent.getStringExtra("answers")
        chcks = intent.getStringExtra("checks")
        ans.text = "Correct Answer is 13"


    }
     fun loadAnswers(view: android.view.View){
        val intent = Intent()
        intent.action = Intent.ACTION_VIEW
        intent.data = chcks?.let{ Uri.parse(chcks)}

        startActivity(intent)
    }



}