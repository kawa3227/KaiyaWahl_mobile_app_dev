package com.example.applab7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun groceryShop(view: android.view.View){
        val layoutRoot = findViewById<ConstraintLayout>(R.id.root_layout)
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        val groceryID = radioGroup.checkedRadioButtonId //int
        val checkBox1 = findViewById<CheckBox>(R.id.breakfast)
        val checkBox2 = findViewById<CheckBox>(R.id.lunch)
        val checkBox3 = findViewById<CheckBox>(R.id.dinner)
        val spinner = findViewById<Spinner>(R.id.spinner)
        val switch = findViewById<Switch>(R.id.switch1)
        var mealList = ""
        if(groceryID == -1){
            val grocerySnackBar = Snackbar.make(layoutRoot, "Please select groceries", Snackbar.LENGTH_SHORT)
            grocerySnackBar.show()
        }else{
            var fill = findViewById<RadioButton>(groceryID).text
            val messageTextView = findViewById<TextView>(R.id.textView)
            val spinner = "buy " + spinner.selectedItem

            if(checkBox1.isChecked){
                mealList += checkBox1.text
            }
            if(checkBox2.isChecked){
                mealList += checkBox2.text
            }
            if(checkBox3.isChecked){
                mealList += checkBox3.text
            }
            if (mealList.isNotEmpty()){
                mealList = "for meal " + mealList
            }
            if (switch.isChecked){
                fill = switch.text.toString() + " $fill"
            }
            messageTextView.text="You need to get $fill for groceries $mealList $spinner"
        }

    }
}