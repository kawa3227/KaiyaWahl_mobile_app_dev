package com.example.lab8

data class dataClass(var answer: String="", var check: String="") {
    fun correctAns(position: Int){
        setAnswer(position)
        checkAns(position)
    }
    private fun setAnswer(position: Int){
        when(position){
            0 -> answer="11"
            1 -> answer="13"
            2 -> answer="15"
        }
    }
    private fun checkAns(position: Int){
        when (position){
            0 -> check="https://www.calculator.net/"
            1 -> check="https://www.youtube.com/watch?v=SC4xMk98Pdc"
            2 -> check="https://www.calculator.net/"
        }
    }
}