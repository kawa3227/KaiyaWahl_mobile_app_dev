package com.example.lab8

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lab8.databinding.ActivityDisplayAnswerBinding

class DisplayAnswer : AppCompatActivity() {

   // private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityDisplayAnswerBinding
    private lateinit var ans : TextView

    private var answers : String? = null
    private var checks : String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDisplayAnswerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        ans=findViewById(R.id.answ)

        answers = intent.getStringExtra("answers")
        checks = intent.getStringExtra("checks")
        checks?.let {ans.text = "correct response is $checks"}

//        val navController = findNavController(R.id.nav_host_fragment_content_display_answer)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
//
//        binding.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show()
//        }
    }
     fun loadAnswers(view: android.view.View){
        val intent = Intent()
        intent.action = Intent.ACTION_VIEW
        intent.data = checks?.let{ Uri.parse(checks)}

        startActivity(intent)
    }

//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_display_answer)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }

}