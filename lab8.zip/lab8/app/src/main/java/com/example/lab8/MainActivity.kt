package com.example.lab8

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Spinner

class MainActivity : AppCompatActivity() {
    private lateinit var answer : Spinner
    private lateinit var check : Button
    private var mydataClass = DataClass()
    private var selectedAnswer = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        check.setOnClickListener {
            selectedAnswer= answer.selectedItemPosition
            mydataClass.correctAns(selectedAnswer)
            Log.i("Answers",mydataClass.answer)
            Log.i("Check",mydataClass.check)
        }
    }
    fun onCreate(view: android.view.View){
        val intent = Intent(this,DisplayAnswer::class.java )
        intent.putExtra("answers",mydataClass.answer)
        intent.putExtra("checks",mydataClass.check)
        startActivity(intent)

    }

}