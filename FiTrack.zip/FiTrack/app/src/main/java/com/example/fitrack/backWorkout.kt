package com.example.fitrack

import android.os.Bundle
import android.widget.Spinner
import android.widget.TextView

import androidx.appcompat.app.AppCompatActivity

import com.example.fitrack.databinding.ActivityBackWorkoutBinding

class backWorkout : AppCompatActivity() {


    // private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityBackWorkoutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityBackWorkoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //setSupportActionBar(binding.toolbar)
//
//        val navController = findNavController(R.id.nav_host_fragment_content_back_workout)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)
        var setSpinner1 = findViewById<Spinner>(R.id.spinner1)
        var repSpinner1 = findViewById<Spinner>(R.id.spinner2)
        var setSpinner2 = findViewById<Spinner>(R.id.spinner3)
        var repSpinner2 = findViewById<Spinner>(R.id.spinner4)
        var Workout1 = findViewById<TextView>(R.id.backWorkout1)
        var Workout2 = findViewById<TextView>(R.id.backWorkout2)




    }



//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_back_workout)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }
}