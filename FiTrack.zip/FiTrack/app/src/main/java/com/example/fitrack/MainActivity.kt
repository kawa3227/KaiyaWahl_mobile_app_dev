package com.example.fitrack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    fun backWorkout(view: android.view.View){
        val intent = Intent(this, backWorkout::class.java)
        startActivity(intent)

    }
//    fun chestWorkout(view: android.view.View){
//
//    }
//    fun cardioWorkout(view: android.view.View){
//
//    }
//    fun armWorkout(view: android.view.View){
//
//    }
//    fun legWorkout(view: android.view.View){
//
//    }
//    fun absWorkout(view: android.view.View){
//
//    }
}