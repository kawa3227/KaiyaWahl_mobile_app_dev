package com.example.fitrack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Spinner
import android.widget.TextView

class ChestWorkout : AppCompatActivity() {
    private lateinit  var setSpin1 : Spinner
    private lateinit var repSpin1 : Spinner
    private lateinit var setSpin2 : Spinner
    private lateinit var repSpin2 : Spinner
    private lateinit var ChestWorkout1 : TextView
    private lateinit var ChestWorkout2 : TextView
    private lateinit var message : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chest_workout)

    }
    fun showChestWorkout(view: android.view.View){
        setSpin1 = findViewById(R.id.ChestsetSpinner1)
        repSpin1 = findViewById(R.id.ChestRepSpinner1)
        setSpin2 = findViewById(R.id.ChestSet2)
        repSpin2 = findViewById(R.id.ChestRep2)
        ChestWorkout1 = findViewById(R.id.Chestworkout1)
        ChestWorkout2 = findViewById(R.id.ChestWorkout2)
        message = findViewById(R.id.message)

        val setSpin1 = setSpin1.selectedItem
        val setSpin2 = setSpin2.selectedItem
        val repSpin1 = repSpin1.selectedItem
        val repSpin2 = repSpin2.selectedItem
        val workout1 = ChestWorkout1.text
        val workout2 = ChestWorkout2.text

        message.text ="Chest workout plan: $workout1 for $setSpin1 sets for $repSpin1 reps, and $workout2 for $setSpin2 sets for $repSpin2 reps. "

    }

}