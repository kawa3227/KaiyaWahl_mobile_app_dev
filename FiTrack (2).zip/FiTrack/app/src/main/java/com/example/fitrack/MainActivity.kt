package com.example.fitrack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    fun backWorkout(view: android.view.View){
        val intent = Intent(this, backWorkout::class.java)
        startActivity(intent)

    }
    fun chestWorkout(view: android.view.View){
        val intent = Intent(this, ChestWorkout::class.java)
        startActivity(intent)

    }
    fun cardioWorkout(view: android.view.View){
        val intent = Intent(this, Cardio::class.java)
        startActivity(intent)
    }
    fun armWorkout(view: android.view.View){
        val intent = Intent(this, Arms::class.java)
        startActivity(intent)
    }
    fun legWorkout(view: android.view.View){
        val intent = Intent(this, Leg::class.java)
        startActivity(intent)
    }

}