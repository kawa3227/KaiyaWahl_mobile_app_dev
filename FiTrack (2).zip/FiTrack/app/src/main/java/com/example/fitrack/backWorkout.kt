package com.example.fitrack

import android.os.Bundle
import android.widget.Spinner
import android.widget.TextView

import androidx.appcompat.app.AppCompatActivity

import com.example.fitrack.databinding.ActivityBackWorkoutBinding

class backWorkout : AppCompatActivity() {


    // private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityBackWorkoutBinding

    private lateinit var setSpinner1 : Spinner
    private lateinit var repSpinner1 : Spinner
    private lateinit var setSpinner2 : Spinner
    private lateinit var repSpinner2 : Spinner
    private lateinit var Workout1 : TextView
    private lateinit var Workout2 : TextView
    private lateinit var message : TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityBackWorkoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //setSupportActionBar(binding.toolbar)
//
//        val navController = findNavController(R.id.nav_host_fragment_content_back_workout)
//        appBarConfiguration = AppBarConfiguration(navController.graph)
//        setupActionBarWithNavController(navController, appBarConfiguration)


    }
    fun showBackWorkout(view: android.view.View){
        setSpinner1 = findViewById(R.id.spinner1)
        repSpinner1 = findViewById(R.id.spinner2)
        setSpinner2 = findViewById(R.id.spinner3)
        repSpinner2 = findViewById(R.id.spinner4)
        Workout1 = findViewById(R.id.backWorkout1)
        Workout2 = findViewById(R.id.backWorkout2)
        message = findViewById(R.id.messageOut)

        val setSpin1 = setSpinner1.selectedItem
        val setSpin2 = setSpinner2.selectedItem
        val repSpin1 = repSpinner1.selectedItem
        val repSpin2 = repSpinner2.selectedItem
        val workout1 = Workout1.text
        val workout2 = Workout2.text

        message.text ="Back workout plan: $workout1 for $setSpin1 sets for $repSpin1 reps, and $workout2 for $setSpin2 sets for $repSpin2 reps. "


    }


//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(R.id.nav_host_fragment_content_back_workout)
//        return navController.navigateUp(appBarConfiguration)
//                || super.onSupportNavigateUp()
//    }
}