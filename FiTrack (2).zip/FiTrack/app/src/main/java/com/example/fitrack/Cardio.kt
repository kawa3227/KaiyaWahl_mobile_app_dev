package com.example.fitrack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Spinner
import android.widget.TextView

class Cardio : AppCompatActivity() {

    private lateinit var Spin1 : Spinner
    private lateinit var Spin2 : Spinner
    private lateinit var CardioWorkout1 : TextView
    private lateinit var CardioWorkout2 : TextView
    private lateinit var message : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cardio)
    }
    fun showCardioWorkout(view: android.view.View){
        Spin1 = findViewById(R.id.cardio1)
        Spin2 = findViewById(R.id.cardio2)
        CardioWorkout1 = findViewById(R.id.cardioWork1)
        CardioWorkout2 = findViewById(R.id.cardioWork2)
        message = findViewById(R.id.messageCard)

        val setSpin1 = Spin1.selectedItem
        val setSpin2 = Spin2.selectedItem
        val workout1 = CardioWorkout1.text
        val workout2 = CardioWorkout2.text

        message.text ="Cardio workout plan: $workout1 for $setSpin1 minutes, and $workout2 for $setSpin2 minutes. "

    }
}