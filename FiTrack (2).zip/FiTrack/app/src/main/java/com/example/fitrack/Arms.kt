package com.example.fitrack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Spinner
import android.widget.TextView

class Arms : AppCompatActivity() {

    private lateinit var setSpin1 : Spinner
    private lateinit var repSpin1 : Spinner
    private lateinit var setSpin2 : Spinner
    private lateinit var repSpin2 : Spinner
    private lateinit var ArmWorkout1 : TextView
    private lateinit var ArmWorkout2 : TextView
    private lateinit var message : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_arms)
    }
    fun showArmWorkout(view: android.view.View){
        setSpin1 = findViewById(R.id.ArmSet1)
        repSpin1 = findViewById(R.id.armRep1)
        setSpin2 = findViewById(R.id.armSet2)
        repSpin2 = findViewById(R.id.armRep2)
        ArmWorkout1 = findViewById(R.id.armWork1)
        ArmWorkout2 = findViewById(R.id.armWork2)
        message = findViewById(R.id.armMessage)

        val setSpin1 = setSpin1.selectedItem
        val setSpin2 = setSpin2.selectedItem
        val repSpin1 = repSpin1.selectedItem
        val repSpin2 = repSpin2.selectedItem
        val workout1 = ArmWorkout1.text
        val workout2 = ArmWorkout2.text

        message.text ="Arm workout plan: $workout1 for $setSpin1 sets for $repSpin1 reps, and $workout2 for $setSpin2 sets for $repSpin2 reps. "

    }
}